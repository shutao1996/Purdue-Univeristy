public class Derived extends Base {

   public Derived( ) { }

  // Add any needed function(s) here.
   public void f1(float f){
	   System.out.println("Derived f1(float)");
	   }
   public void f1( ){
	   System.out.println("Base f1");
	   
   }

}

